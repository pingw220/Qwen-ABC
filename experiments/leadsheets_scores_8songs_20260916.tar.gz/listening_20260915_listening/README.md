# Samples

data: `data/generated/abc_v2_20260915_120927`

| song | E0_T0.8: strict / lyric recall / chord-tone | E0_T1.0: strict / lyric recall / chord-tone | E1_T0.8: strict / lyric recall / chord-tone | E1_T1.0: strict / lyric recall / chord-tone | E3_T0.8: strict / lyric recall / chord-tone | MIDI_LLM_A: strict / lyric recall / chord-tone |
|---|---|---|---|---|---|---|
| 1tKSEmbS7vmv7cFc24sjlI | 1 / 0.97 / 0.80 | 1 / 1.00 / 0.77 | 1 / 1.00 / 0.82 | 1 / 1.00 / 0.69 | 1 / 1.00 / 0.85 | 1 / 0.72 / 0.60 |
| 2HVhqSDfh4XVdrRJuwpG6x | 0 / 0.74 / 0.69 | 1 / 1.00 / 0.47 | 0 / 1.00 / 0.64 | 1 / 0.99 / 0.62 | 0 / 0.97 / 0.63 | 1 / 0.90 / 0.59 |
| 7qDiugtLVz4njwHDGCfdB5 | 1 / 0.99 / 0.80 | 1 / 0.95 / 0.64 | 0 / 0.96 / 0.71 | 0 / 0.95 / 0.59 | 0 / 0.93 / 0.82 | 1 / 0.85 / 0.56 |
| 5CbNIRIgmrh1W9xNnhtSz1 | 0 / 0.99 / 0.84 | 0 / 0.99 / 0.74 | 1 / 0.99 / 0.75 | 1 / 0.99 / 0.60 | 0 / 0.95 / 0.79 | 0 / nan / nan |
| 1Fo23uW11ZN4JCFCeB0ngS | 1 / 0.98 / 0.58 | 0 / 0.97 / 0.26 | 0 / 0.86 / 0.54 | 0 / 0.93 / 0.65 | 0 / 0.38 / 0.82 | 1 / 0.68 / 0.63 |
| 5rc5x4FKWvrJb8qxFNp1bO | 1 / 1.00 / 0.84 | 0 / 0.84 / 0.76 | 1 / 1.00 / 0.79 | 1 / 0.97 / 0.86 | 0 / 1.00 / 0.78 | 1 / 0.58 / 0.75 |
| 28I269iDvkDyb2Fqo2p1TI | 1 / 0.99 / 0.85 | 1 / 1.00 / 0.64 | 0 / 0.67 / 0.28 | 0 / 0.99 / 0.70 | 1 / 0.98 / 0.78 | 1 / 0.87 / 0.70 |
| 3X3BdYpVpN78IFIpmhhEmU | 0 / 0.99 / 0.83 | 1 / 1.00 / 0.70 | 1 / 1.00 / 0.88 | 1 / 1.00 / 0.70 | 0 / 1.00 / 0.77 | 1 / 0.87 / 0.67 |
