# Samples

data: `data/generated/abc_v2_20260915_120927`

| song | E0_round1_default_T0.8: strict / lyric recall / chord-tone | E3b_best_T0.8: strict / lyric recall / chord-tone | E3b_best_T1.0: strict / lyric recall / chord-tone | MIDI_LLM_A: strict / lyric recall / chord-tone |
|---|---|---|---|---|
| 1tKSEmbS7vmv7cFc24sjlI | 1 / 0.97 / 0.80 | 1 / 1.00 / 0.82 | 1 / 1.00 / 0.36 | 1 / 0.72 / 0.60 |
| 7qDiugtLVz4njwHDGCfdB5 | 1 / 0.99 / 0.80 | 1 / 0.99 / 0.69 | 1 / 0.96 / 0.70 | 1 / 0.85 / 0.56 |
| 5CbNIRIgmrh1W9xNnhtSz1 | 0 / 0.99 / 0.84 | 0 / 0.99 / 0.91 | 1 / 0.99 / 0.72 | 0 / nan / nan |
| 1Fo23uW11ZN4JCFCeB0ngS | 1 / 0.98 / 0.58 | 1 / 0.95 / 0.59 | 1 / 0.95 / 0.75 | 1 / 0.68 / 0.63 |
